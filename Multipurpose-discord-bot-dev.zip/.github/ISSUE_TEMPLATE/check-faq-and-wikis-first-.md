---
name: Check FAQ AND WIKIS FIRST!
about: Before opening an ISSUE, make sure to check the WIKI and the README.MD file
  (setup explanation) first!
title: Check FAQ AND WIKIS FIRST!
labels: invalid, wontfix
assignees: ''

---

# [Readme & Installation Guide](https://github.com/Tomato6966/Multipurpose-discord-bot#installation-guide-

# [WIKI & FAQ](https://github.com/Tomato6966/Multipurpose-discord-bot/wiki#faq)
